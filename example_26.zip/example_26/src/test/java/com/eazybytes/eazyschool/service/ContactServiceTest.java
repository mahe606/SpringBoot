package com.eazybytes.eazyschool.service;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

class ContactServiceTest {

    @BeforeEach
    void setUp() {
    }

    @AfterEach
    void tearDown() {
    }

    @Test
    void saveMessageDetails() {

    }

    @Test
    void getCounter() {
    }

    @Test
    void setCounter() {
    }

    @Test
    void add() {
        ContactService contactService= new ContactService();
        assertEquals(5, contactService.add(3, 3));
    }

    @Test
    void sub() {
    }
}